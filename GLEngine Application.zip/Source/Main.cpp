#include "Main.h"

int main(int argc, char* argv[])
{
	$safeprojectname$::Game game;

	return game.run();
}
